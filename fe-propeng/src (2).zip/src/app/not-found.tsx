// app/not-found.tsx
export { default } from './(404-layout)/not-found';