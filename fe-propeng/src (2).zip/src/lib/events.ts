// Custom event names used throughout the application
export const LINIMASA_UPDATED_EVENT = "linimasa_updated"; 